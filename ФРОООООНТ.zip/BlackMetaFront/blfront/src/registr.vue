<template>
    <div class="register">
      <h1>Регистрация</h1>
      <form @submit.prevent="register">
        <label for="login">Логин:</label>
        <input type="text" id="login" v-model="registerForm.login">
        <br>
        <label for="password">Пароль:</label>
        <input type="password" id="password" v-model="registerForm.password">
        <br>
        <label for="repeatPassword">Повторите пароль:</label>
        <input type="password" id="repeatPassword" v-model="registerForm.repeatPassword">
        <br>
        <button type="submit">Зарегистрироваться</button>
        <p v-if="error" style="color: red;">{{ error }}</p>
      </form>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        registerForm: {
          login: '',
          password: '',
          repeatPassword: ''
        },
        error: ''
      }
    },
    methods: {
      register() {
        if (this.registerForm.password !== this.registerForm.repeatPassword) {
          this.error = "Пароли не совпадают";
        } else {
          // код для регистрации
          console.log("Регистрация выполнена");
        }
      }
    }
  }
  </script>