<template>
  <div class="container">
    <header>
      <nav>
        <ul>
          <li><button @click="$router.push('/login')">Войти</button></li>
          <li><button @click="$router.push('/register')">Регистрация</button></li>
        </ul>
      </nav>
    </header>
    <main>
      <section class="player">
        <audio id="player" ref="player" controls>
          <source id="audioSource" src="" type="audio/mp3">
          Your browser does not support the audio element.
        </audio>
        <input type="file" id="fileInput" @change="handleFileChange">
        <button id="playButton" @click="playAudio">Play</button>
        <button id="pauseButton" @click="pauseAudio">Pause</button>
        <button id="nextButton" @click="nextTrack">Next</button>
        <button id="prevButton" @click="prevTrack">Prev</button>
        <ul id="tracklist">
          <li v-for="(track, index) in tracks" :key="index" @click="playTrack(index)">
            {{ track.name }}
          </li>
        </ul>
      </section>
    </main>
  </div>
</template>


<script>
export default {
  inject: ['$root'],
  data() {
    return {
      audioFile: null,
      tracks: []
    }
  },
  methods: {
    handleFileChange(event) {
      this.audioFile = event.target.files[0];
      this.tracks.push({ name: this.audioFile.name, src: URL.createObjectURL(this.audioFile) });
      this.$refs.player.src = this.tracks[0].src;
    },
    playAudio() {
      this.$refs.player.play();
    },
    pauseAudio() {
      this.$refs.player.pause();
    },
    nextTrack() {
      const currentIndex = this.tracks.findIndex(track => track.src === this.$refs.player.src);
      if (currentIndex < this.tracks.length - 1) {
        this.$refs.player.src = this.tracks[currentIndex + 1].src;
      }
    },
    prevTrack() {
      const currentIndex = this.tracks.findIndex(track => track.src === this.$refs.player.src);
      if (currentIndex > 0) {
        this.$refs.player.src = this.tracks[currentIndex - 1].src;
      }
    },
    playTrack(index) {
      this.$refs.player.src = this.tracks[index].src;
      this.$refs.player.play();
    }
  }
}
</script>

<style>
.container {
  max-width: 800px;
  margin: 40px auto;
  padding: 20px;
  background-image: linear-gradient(to bottom, #660000, #330000, #000000);
  background-size: 100% 300px;
  background-position: 0% 100%;
  transition: background-position 0.5s ease-out;
}

.player {
  margin-top: 20px;
  background-color: #660000; /* Красный цвет плеера */
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

#player {
  width: 100%;
  height: 40px;
  background-color: #330000; /* Темнокрасный цвет плеера */
  padding: 10px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

#fileInput {
  margin-top: 10px;
}

#playButton {
  margin-top: 10px;
  background-color: #4CAF50;
  color: #fff;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

#playButton:hover {
  background-color: #3e8e41;
}

#pauseButton {
  margin-top: 10px;
  background-color: #ff9800;
  color: #fff;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

#pauseButton:hover {
  background-color: #ff9900;
}
</style>
