<template>
    <div class="login">
      <h1>Вход</h1>
      <form @submit.prevent="login">
        <label for="login">Логин:</label>
        <input type="text" id="login" v-model="loginForm.login">
        <br>
        <label for="password">Пароль:</label>
        <input type="password" id="password" v-model="loginForm.password">
        <br>
        <button type="submit">Войти</button>
      </form>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        loginForm: {
          login: '',
          password: ''
        }
      }
    },
    methods: {
      login() {
        // код для входа в систему
        console.log("Вход выполнен");
      }
    }
  }
  </script>